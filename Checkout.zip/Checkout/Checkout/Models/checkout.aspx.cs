﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Checkout
{
    public partial class checkout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            populateCardExp();
            populateProvince();
        }

        /* Write a function that adds numbers 1-12 to the ddlMonthExp dropdown list.
         * If a number is a single digit such as 1 it should appear as "01" in the dropdown
           list. The function should also set the ddlYearExp dropdown lsit to +- 5 years from the current
           year (i.e. 2013 - 2023)*/
        protected void populateCardExp()
        {
           
        }

        /* Write a function that populates the ddlProvince list with all 13 province abbreviations */
        protected void populateProvince()
        {
            
            
        }

        protected void chkSameShipping_CheckedChanged(object sender, EventArgs e)
        {
            if(chkSameShipping.Checked == true)
            {
                txtPhone.Enabled = false;
                txtAddress1.Enabled = false;
                txtAddress2.Enabled = false;
                txtCity.Enabled = false;
                txtPostalCode.Enabled = false;
            
            }
            if (chkSameShipping.Checked == false)
            {
                txtPhone.Enabled = true;
                txtAddress1.Enabled = true;
                txtAddress2.Enabled = true;
                txtCity.Enabled = true;
                txtPostalCode.Enabled = true;

            }
        }

        protected void txtCrdNum_TextChanged(object sender, EventArgs e)
        {
            txtNameCard.Text = "";
            txtSecurityCode.Text = "";
            ddlMonthExp.SelectedIndex = 0;
            ddlYearExp.SelectedIndex = 0;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            ddlMonthExp.SelectedIndex = 0;
            ddlProvince.SelectedIndex = 0;
            ddlYearExp.SelectedIndex = 0;
            txtCrdNum.Text = "";
            txtNameCard.Text = "";
            txtSecurityCode.Text = "";
            txtAddress1.Text = "";
            txtAddress2.Text = "";
            txtCity.Text = "";
            txtPostalCode.Text = "";
            txtPhone.Text = "";
        }

        protected void ddlMonthExp_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}